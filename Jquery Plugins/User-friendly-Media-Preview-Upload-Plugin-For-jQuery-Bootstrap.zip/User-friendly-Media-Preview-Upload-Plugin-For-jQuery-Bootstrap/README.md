# multiple-mediaselect
using jquery and bootstrap by this you can create multiple file selector,preview on boostrap modal,also able to delete file.
