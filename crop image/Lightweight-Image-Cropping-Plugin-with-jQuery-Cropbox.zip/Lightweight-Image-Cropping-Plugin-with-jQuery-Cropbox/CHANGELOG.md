jquery-cropbox
--------------

### v1.0.1 [2015-09-13]

- Bug #2: if you use any js script which using "mouseup" event it's not working because jquery-cropbox stops every mouseup event after itself (kwolfy)

### v1.0.0 [2015-09-13]

- First release.
