<style type="text/css">

    table.page_header {width: 100%; border: none; background-color: #245e8a;  padding: 2mm; color: white; }
    table.page_footer {width: 100%; border: none; background-color: #245e8a; padding: 2mm; color: white;}
    div.note {color: #333; font-style: italic; width: 100%; }
    ul.main { width: 95%; list-style-type: square; }
    ul.main li { padding-bottom: 2mm; }
    h1 { text-align: center; font-size: 20mm}
    h3 { text-align: center; font-size: 14mm}
    a { text-decoration: none; color: white;}

</style>
<page backtop="14mm" backbottom="14mm" backleft="10mm" backright="10mm" style="font-size: 12pt">
    <page_header>
        <table class="page_header">
            <tr>
                <td style="width: 50%; text-align: left">
                    Subscribe: YouTube.com/myPHPnotes
                </td>
                <td style="width: 50%; text-align: right">
                    Visit: www.myphpnotes.tk
                </td>
            </tr>
        </table>
    </page_header>
    <page_footer>
        <table class="page_footer">
            <tr>
                <td style="width: 33%; text-align: left;">
                    <a href="https://myphpnotes.tk/">https://myphpnotes.tk</a>
                </td>
                <td style="width: 34%; text-align: center">
                    Page [[page_cu]]/[[page_nb]]
                </td>
                <td style="width: 33%; text-align: right">
                    <?php echo date('d.m.Y h.m.sA'); ?>
                </td>
            </tr>
        </table>
    </page_footer>
    <br><br><br><br><br><br><br><br><br><br>
    <div style="text-align: center; width: 100%;">
        <img src="logo.png" alt="Logo myPHPnotes" style="width: 50mm">
        <h3 style="font-style: italic; color: #333;">myPHPnotes.tk</h3>
    </div>
    <br><br>
    <div class="note" style="text-align: center; ">
       <?php echo nl2br($data); ?>
    </div>
</page>


